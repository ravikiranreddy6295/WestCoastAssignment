import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import java.time.Duration;
import java.lang.*;

public class MyAssignment {
        WebDriver driver=null;

    @BeforeTest
        public void setup(){

            WebDriverManager.chromedriver().setup();
            ChromeOptions options = new ChromeOptions();
            options.addArguments("--remote-allow-origins=*");
            driver = new ChromeDriver(options);
            driver.manage().window().maximize();
            driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

            System.out.println("Launching booking.com flight website");
            driver.get("https://flights.booking.com/");
            String expectedTitle= "Book your flight - Booking.com";
            String actualTitle=driver.getTitle();
            Assert.assertEquals(actualTitle,expectedTitle);
        }

        @Test(priority = 0)
        public void roundTrip() {
            //click on round trip
            WebElement l = driver.findElement(By.xpath("(//span[@class='InputRadio-module__field___4Jbyo'])[1]"));
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", l);

        }
        @Test(priority = 1)
        public void sourceDestination() {

            //selecting London as source
            driver.findElement(By.xpath("(//button[@class='css-1ovag24'])[1]")).click();
            driver.findElement(By.xpath("(//span[@class='css-rh2lq6']/following-sibling::span)[1]")).click();
            driver.findElement(By.xpath("//input[@placeholder='Airport or city']")).sendKeys("London");
            driver.findElement(By.xpath("(//span[@class='css-3cj1dx']//span)[1]")).click();

            //Selecting New york as destination
            driver.findElement(By.xpath("(//button[@class='css-1ovag24'])[2]")).click();
            driver.findElement(By.xpath("//div[@class='css-3y0hds']//input[1]")).sendKeys("New York");
            driver.findElement(By.xpath("(//span[@class='css-3cj1dx']//span)[1]")).click();
        }
        @Test(priority = 2)
        public void startEndDate() {
            //Selecting Start date and end date
            driver.findElement(By.xpath("(//button[@class='css-1ovag24'])[3]")).click();
            driver.findElement(By.xpath("(//span[@aria-label='31 July 2023']//span)[2]")).click();
            driver.findElement(By.xpath("(//div[@data-ui-name='calendar_body']//button)[2]")).click();
            driver.findElement(By.xpath("(//div[@data-ui-name='calendar_body']//button)[2]")).click();
            driver.findElement(By.xpath("(//span[@aria-label='17 August 2023']//span)[2]")).click();
        }
        @Test(priority = 3)
        public void searchFlights() {

            //click on the search button
            driver.findElement(By.xpath("//button[@data-ui-name='button_search_submit']")).click();

            //click on fastest
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
            WebElement test = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//li[@class='Tab-module__item___t3KVI']//button)[3]")));
            test.click();

            //click on see flight
            driver.findElement(By.xpath("(//div[@class='css-1niqckn']/following-sibling::button)[2]")).click();
        }
        @Test(priority = 4)
        public void validateYourFlightDetails() throws InterruptedException {

            //verify start date
            String expectedStartDate = "Mon 31 Jul";
            Thread.sleep(5000);
            String actual = driver.findElement(By.xpath("(//div[@class='css-17qtwxq']//div)[3]")).getText();
            if (actual.contains(expectedStartDate))
                System.out.println("Test passed");
            else
                System.out.println("Test Failed");

            //verify return date
            String expectedEndDate = "Thu 17 Aug";
            String actualEndDate = driver.findElement(By.xpath("(//div[@class='Text-module__root--variant-small_2___Db1tb css-15jxk80'])[3]")).getText();
            if (actualEndDate.contains(expectedEndDate))
                System.out.println("Test passed");
            else
                System.out.println("Test Failed");

            //verify flight time
            String expectedTime = driver.findElement(By.xpath("(//div[@data-testid='timeline_location_timestamp_departure'])[1]")).getText();
            String actualTime = driver.findElement(By.xpath("(//div[@data-testid='flight_card_segment_departure_time_0'])[2]")).getText();
            String expected=expectedTime.substring(13,18);
            System.out.println(expected);
            Assert.assertEquals(actualTime,expected);


            //verify price
            String expectedPrice= driver.findElement(By.xpath("(//div[@class='css-vxcmzt'])[2]")).getText();
            String actualPrice = driver.findElement(By.xpath("(//div[text()='Total price for all travellers'])[16]//preceding-sibling::div//h2//div")).getText();
            Assert.assertEquals(actualPrice,expectedPrice);

            //click on select
            driver.findElement(By.xpath("(//div[@class='css-95bx75']//button)[2]")).click();

            //Check that “price” in the “London to New York” page is correct
            WebDriverWait waits = new WebDriverWait(driver, Duration.ofSeconds(20));
            WebElement price = waits.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@data-testid='breakdown_list_text']/following-sibling::div[1]")));
            String actualCost = price.getText();
            Assert.assertEquals(actualCost,expectedPrice);

        }

        @AfterTest
        public void tearDown() {
            driver.quit();
        }

    }

